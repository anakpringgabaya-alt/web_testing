const games = [
  { name:"8768D", logo:"8768d.png", link:"https://example.com" },
  { name:"KAKRP", logo:"kakrp.png", link:"https://example.com" },
  { name:"PRAGMATIC PLAY", logo:"pragmatic.png", link:"https://example.com" }
];